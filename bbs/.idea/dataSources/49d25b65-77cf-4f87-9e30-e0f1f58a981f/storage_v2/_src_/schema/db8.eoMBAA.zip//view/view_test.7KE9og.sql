create view view_test as
  select `db8`.`nt1`.`id`     AS `id`,
         `db8`.`nt1`.`usr`    AS `usr`,
         `db8`.`nt1`.`age`    AS `age`,
         `db8`.`nt1`.`gender` AS `gender`
  from `db8`.`nt1`
  where (`db8`.`nt1`.`id` = 1);

