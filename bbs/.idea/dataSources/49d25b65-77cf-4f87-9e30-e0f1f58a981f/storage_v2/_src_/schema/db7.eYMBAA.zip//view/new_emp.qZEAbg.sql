create view new_emp as (select `db7`.`emp`.`id` AS `id`, `db7`.`emp`.`name` AS `姓名`, `db7`.`emp`.`salary` AS `工资`
                        from `db7`.`emp`
                        where (`db7`.`emp`.`dep_id` = 1));

